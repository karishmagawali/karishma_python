j=int(input("enter a number 1:"))
k=int(input("enter a number 2:"))
temp=j
j=k
k=temp
print("after swapping 1:",j)
print("after swapping 2:",k)
