c=int(input("enter a number:"))
d=int(input("enter a number:"))
s=int(input("enter a number:"))
if(c>d and c>s):
    print("c is greater",c)
elif(d>c and  d>s):
    print("d is greater",d)
else:
    print("s is greater",s)
