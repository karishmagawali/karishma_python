a="Name:'Utkarsh'\t\t\t\t Designation:'Factulty'\nID:'321ABZ'\t\t\t\t Password:'zzz@123'\nEmail:'abc1234@gmail.com'"
print(a)
