i=int(input("enter a number:"))
h=1
while i>=1:
    h=h*i
    i=i-1
print(h)
